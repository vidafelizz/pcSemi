package common;

public class Constants {
	//파일이 업로드되고 관리되는 디렉토리
	public static final String UPLOAD_PATH = "c:\\upload\\";
	//파일 업로드 용량 제한(10mb)
	public static final int MAX_UPLOAD = 10*1024*1024;

}
